import logo from "./logo.svg";
import "./App.css";
import UserDash from "./UserDash";
import Gantt from "./Gantt";
import TimeLine from "./TimeLine.jsx"


import SideNavbar from "./SideNavbar";


function App() {
  return (
    <div>
      <div className="app">
        <div className="NavbarSection">
          <SideNavbar />
        </div>
        <div className="main">
          {/* <Gantt /> */}
          <TimeLine />
        </div>
      </div>
    </div>
  );
}

export default App;
