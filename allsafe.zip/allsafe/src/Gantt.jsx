import React from "react";
import "./Gantt.css";
import { BarChartOutlined } from "@ant-design/icons";
import { EnvironmentOutlined, DollarCircleOutlined, DownCircleOutlined } from "@ant-design/icons";
import { RiseOutlined } from "@ant-design/icons";
import { DownOutlined } from "@ant-design/icons";
import { MonitorOutlined } from "@ant-design/icons";
import { UserOutlined } from "@ant-design/icons";
import { Table, Tag, Space } from "antd";
import { Button } from 'react-bootstrap';
const Gantt = () => {
  return (
    <div>
      <div id="ganttTop">
        <p id="menuTable">
          {" "}
          <BarChartOutlined /> Main Table
        </p>
        <p>
          {" "}
          <EnvironmentOutlined />
          Map
        </p>
        <p>
          {" "}
          <RiseOutlined /> Timeline
        </p>
      </div>
      <hr id="ganttTopHeight" />
      <div id="ganttSecondTable">
        <div class="dropdown">
          <span id="dropDownBtn">
            New Item <DownOutlined />
          </span>
          <div class="dropdown-content">
            <p>Hello World!</p>
          </div>
        </div>
        <p id="ganttsearch">Search</p>
        <p id="ganttPerson">Person </p>
        <p id="ganttFilter">Filter <DownOutlined /></p>
      </div>
      <div id="ganttMainTables">
        <div id="initiationTable">
            <h1> <DownCircleOutlined id="initiationIcon"/>Initiation</h1>
            <div id="ganttMainSec"> 
            <table>
    <tr>
      <th></th>
      <th>Project Manager</th>
      <th>Status</th>
      <th>Timeline</th>
      <th>Location</th>
      <th>Total Budget</th>
      <th>Budget Spent</th>
      <th>Budget Status</th>
      <th>Budget Gaps</th>
      <th>Upcoming Meeting</th>
      <th>Deliveries</th>
      
    </tr>
   
    <tr>
    
      <td id="initiation">Project Discussion</td>
      <td id="projectManger"><UserOutlined id="userIcon"/></td>
      <td id="status"></td>
      <td id="timeLine">
        <div id="timeLineSec">
<p>Nov 26 - Dec 31</p>
        </div>
      </td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Budget</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Mon, Dec 01, 21</td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>
      
    </tr>
    <tr>
      <td id="initiation">Construction Project</td>
      <td id="projectManger"><UserOutlined id="userIcon"/></td>
      <td id="status" style={{backgroundColor: "#009DAE"}}></td>
      <td id="timeLine">
        <div id="timeLineSec">
<p>Nov 26 - Dec 31</p>
        </div>
      </td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Budget</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Mon, Dec 01, 21</td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>

    </tr>
   
    <tr>
      <td id="initiation">Hi Agency</td>
      <td id="projectManger"><UserOutlined id="userIcon"/></td>
      <td id="status"  style={{backgroundColor: "#EC255A"}}></td>
      <td id="timeLine">
        <div id="timeLineSec">
<p>Nov 26 - Dec 31</p>
        </div>
      </td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Budget</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Mon, Dec 01, 21</td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>

    </tr>
    <tr>
      <td id="initiation">Hill Agency</td>
      <td id="projectManger"><UserOutlined id="userIcon"/></td>
      <td id="status" style={{backgroundColor: "#519259"}}></td>
      <td id="timeLine">
        <div id="timeLineSec">
<p>Nov 26 - Dec 31</p>
        </div>
      </td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Budget</td>
      <td id="totalBudget"><DollarCircleOutlined /> 0000</td>
      <td id="totalBudget">Mon, Dec 01, 21</td>
      <td id="location"><EnvironmentOutlined /> Fairview, New Jersy</td>

    </tr>
   
  </table>

            </div>
        </div>
      </div>
    </div>
  );
};

export default Gantt;
