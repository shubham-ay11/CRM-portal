import React, {useState, useEffect} from "react";
import "./SideNavbar.css";
import userImg from "./images/userImg.png";
import { Button, Menu, Typography, Avatar } from 'antd';
import {MenuOutlined } from '@ant-design/icons';





const SideNavbar = () =>{

  const [activeMenu, setActiveMenu] = useState(true);
  const [screenSize, setScreenSize] = useState(undefined);

  useEffect(() => {
    const handleResize = () => setScreenSize(window.innerWidth);

    window.addEventListener('resize', handleResize);

    handleResize();

    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (screenSize <= 800) {
      setActiveMenu(false);
    } else {
      setActiveMenu(true);
    }
  }, [screenSize]);


  return (
    <div id="sideNavbody">
    <Button className="menu-control-container" onClick={() => setActiveMenu(!activeMenu)} id="navbtn"><MenuOutlined /></Button>
    {activeMenu && (
      <div id="sideNav">
        <div id="userDetailSec">
          <img src={userImg} id="userImg"></img>
          <h1 id="userName">Shubham Joshi</h1>
        </div>
        <div>
<input id="navSerachBar" placeholder="Search"></input>

      </div>
      <div id="sideNavList">
      <p id="sideNavList1">My Project</p>
      <p id="sideNavList2">My Task</p>
      <p id="sideNavList3">Book Deliveries</p>
      
      </div>
      </div>
      
    )}
      
    </div>
  );
};

export default SideNavbar;
