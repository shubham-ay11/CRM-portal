import React from 'react';
import "./TimeLine.css";
import { BarChartOutlined } from "@ant-design/icons";
import { EnvironmentOutlined, DollarCircleOutlined, DownCircleOutlined } from "@ant-design/icons";
import { RiseOutlined } from "@ant-design/icons";
import { DownOutlined } from "@ant-design/icons";
import { MonitorOutlined } from "@ant-design/icons";
import { UserOutlined } from "@ant-design/icons";
import { Table, Tag, Space } from "antd";

import { GanttComponent, TaskFieldsModel, ColumnsDirective, ColumnDirective } from '@syncfusion/ej2-react-gantt';
import { projectData } from './data';

const TimeLine = () => {


  const taskValues = {
    id: "TaskID",
    name: "TaskName",
    startDate: "StartDate",
    endDate: "EndDate",
    duration: "Duration",
    progress: "Progress",
    child: "subtasks",
    dependency: "Predeceesor"
  }
    return (
        <div>

<div id="TimeLineTop">
        <p id="menuTableTL">
          {" "}
          <BarChartOutlined /> Main Table
        </p>
        <p>
          {" "}
          <EnvironmentOutlined />
          Map
        </p>
        <p>
          {" "}
          <RiseOutlined /> Timeline
        </p>
      </div>
      <hr id="ganttTopHeightTL" />

      <div id="ganttSecondTableTL">
        <div class="dropdown">
          <span id="dropDownBtn">
            New Item <DownOutlined />
          </span>
          <div class="dropdown-content">
            <p>Hello World!</p>
          </div>
        </div>
        <p id="ganttsearch">Search</p>
        <p id="ganttPerson">Person </p>
        <p id="ganttFilter">Filter <DownOutlined /></p>
      </div>
      <div id="ganttMainTables">
        <div id="initiationTable">
            <h1> <DownCircleOutlined id="initiationIcon"/>Initiation</h1>
           
        </div>
      </div>
      {/* <div id="timeLineTable"> */}
      <GanttComponent dataSource={projectData}
      taskFields={taskValues}>
        <ColumnsDirective>
          <ColumnDirective field="TaskID" headerText="ID" className="ganttData"></ColumnDirective>
          <ColumnDirective field="TaskName" headerText="Name" className="ganttData"></ColumnDirective>
          <ColumnDirective field="StartDate" format="dd-MMM-yy" className="ganttData"></ColumnDirective>
          <ColumnDirective field="Duration" textAlign="Right" className="ganttData"></ColumnDirective>
        </ColumnsDirective>
      </GanttComponent>
      {/* </div> */}
        </div>
    )
}

export default TimeLine
