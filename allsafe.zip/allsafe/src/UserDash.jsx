import React from 'react';
import "./UserDash.css";
import {FileFilled} from '@ant-design/icons';
import {CheckCircleFilled} from '@ant-design/icons';
import {ClockCircleFilled} from '@ant-design/icons';
const UserDash = () => {
    return (
        <div>
        <div id="userDashTop">
       <p>
           
       </p>
        </div>
            <div id="userDasNav">
<p className="link1">Daily</p>
<p>Calendar</p>
<p>Gantt</p>
            </div>

            <div id="userDashmain">
            <h1>CPM</h1>
            <div id="cpmTaskBox">
            <div id="cpmTask">
            <FileFilled id="antIcon"/>
            <h1>Menu - </h1>
            <h1>My Project |</h1>
            <h1>My tasks |</h1>
            <h1>Active Projects |</h1>
            
            </div>
            <div id="cpmTaskStatus">
<CheckCircleFilled id="completedIcon"/>
<p>Completed</p>
</div>
           
</div>
 <div id="cpmTaskBox">
            <div id="cpmTask">
            <FileFilled id="antIcon"/>
            <h1>Menu - </h1>
            <h1>My Project |</h1>
            <h1>My tasks |</h1>
            <h1>Active Projects |</h1>
            
            </div>
            <div id="cpmTaskStatus">
            <ClockCircleFilled  id="completedIcon"/>
<p>Due Tomorrow</p>
</div>
           
</div>

           
            </div>
        </div>
    )
}

export default UserDash
